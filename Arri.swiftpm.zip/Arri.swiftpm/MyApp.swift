import SwiftUI

@main
struct Arri: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
