//
//  ContentView.swift
//  Arri
//
//  Created by Vishesh Singh Rajput (specstan) and finalized on 23/02/25.
//

import SwiftUI

// MARK: - Model

struct ExpenseItem: Identifiable {
    var id = UUID()
    var name: String
    var amount: Double
    var category: String
    var currency: String
}

// MARK: - Expense Assessment

enum ExpenseAssessment {
    case acceptable(String)
    case overpriced(String)
    case investForFuture(String)
}

// MARK: - View Model

@MainActor
final class ExpenseViewModel: ObservableObject {
    @Published var expense = ExpenseItem(name: "", amount: 0.0, category: "Food", currency: "USD")
    @Published var assessment: ExpenseAssessment? = nil
    
    // Base thresholds in USD for each category.
    private let thresholdsUSD: [String: Double] = [
        "Food": 30,
        "Transportation": 50,
        "Entertainment": 40,
        "Utilities": 100,
        "Shopping": 60,
        "Other": 20
    ]
    
    // Conversion rates: only USD is defined by default.
    private var conversionRates: [String: Double] = [
        "USD": 1.0
    ]
    
    init() {
        // Update the conversion rate for INR asynchronously.
        Task { [weak self] in
            await self?.updateConversionRates()
        }
    }
    
    /// Evaluates the expense based on the selected category and currency.
    func evaluateExpense(input: String, for category: String, in currency: String) {
        guard let amount = Double(input) else {
            assessment = .overpriced("Please enter a valid numeric amount.")
            return
        }
        
        expense.amount = amount
        expense.category = category
        expense.currency = currency
        
        let rate = conversionRates[currency] ?? 1.0
        let baseThreshold = thresholdsUSD[category] ?? 25.0 // Temporary hardcoded implementation; CoreML customization planned for scalable deployment
        let adjustedThreshold = baseThreshold * rate
        
        // For essential expenses, always accept.
        if category == "Food" || category == "Utilities" {
            assessment = .acceptable("Your \(category) expense is essential and acceptable in \(currency).")
            return
        }
        
        if amount < adjustedThreshold {
            assessment = .acceptable("Your \(category) expense is within a reasonable range in \(currency).")
        } else if amount < (adjustedThreshold * 2) {
            assessment = .overpriced("This \(category) expense seems a bit high in \(currency). Consider alternatives.")
        } else {
            assessment = .investForFuture("This expense is quite high for \(category) in \(currency). You might consider investing that amount for future needs.")
        }
    }
    
    /// Asynchronously fetches the latest USD-to-INR exchange rate.
    func updateConversionRates() async {
        guard let url = URL(string: "https://api.exchangerate-api.com/v4/latest/USD") else { return }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let rates = json["rates"] as? [String: Double],
               let inrRate = rates["INR"] {
                conversionRates["INR"] = inrRate
            }
        } catch {
            print("Error fetching conversion rate: \(error)")
        }
    }
}


// MARK: - Custom View Modifier

struct GlassEffectModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(12)
            .background(.thinMaterial)
            .cornerRadius(12)
            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
            .padding(.horizontal, 15)
    }
}

extension View {
    func glassEffect() -> some View {
        self.modifier(GlassEffectModifier())
    }
}

// MARK: - Main Content View

struct ContentView: View {
    @StateObject private var viewModel = ExpenseViewModel()
    @State private var amountText: String = "0"
    @FocusState private var isAmountFieldFocused: Bool
    @State private var selectedCategory: String = "Food"
    @State private var selectedCurrency: String = "USD"
    @State private var showAssessment: Bool = false
    
    private let categories = ["Food", "Transportation", "Entertainment", "Utilities", "Shopping", "Other"]
    private let currencies = ["USD", "INR"]
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background gradient that fills the screen
                AngularGradient(
                    gradient: Gradient(colors: [Color.blue, Color.purple, Color.pink, Color.orange]),
                    center: .center
                )
                .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    // App Title
                    Text("Arri")
                        .font(.system(size: 100, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.top, 50)
                    
                    Text("Smart Expense Advisor")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.9))
                    
                    Spacer()
                    
                    // Input Card
                    VStack(spacing: 15) {
                        HStack {
                            Image(systemName: "tag")
                                .foregroundColor(.blue)
                            TextField("Expense Name", text: $viewModel.expense.name)
                                .glassEffect()
                        }
                        
                        HStack {
                            Image(systemName: "dollarsign.circle")
                                .foregroundColor(.green)
                            TextField("Amount", text: $amountText)
                                .keyboardType(.decimalPad)
                                .glassEffect()
                                .focused($isAmountFieldFocused)
                                .onChange(of: isAmountFieldFocused) { focused in
                                    if focused && amountText == "0" {
                                        amountText = ""
                                    }
                                }
                        }
                        
                        HStack {
                            Image(systemName: "square.grid.2x2")
                                .foregroundColor(.orange)
                            Picker("Category", selection: $selectedCategory) {
                                ForEach(categories, id: \.self) { category in
                                    Text(category)
                                }
                            }
                            .pickerStyle(MenuPickerStyle())
                            .glassEffect()
                        }
                        
                        HStack {
                            Image(systemName: "dollarsign.circle.fill")
                                .foregroundColor(.yellow)
                            Picker("Currency", selection: $selectedCurrency) {
                                ForEach(currencies, id: \.self) { currency in
                                    Text(currency)
                                }
                            }
                            .pickerStyle(MenuPickerStyle())
                            .glassEffect()
                        }
                    }
                    .padding()
                    .background(Color.white.opacity(0.25))
                    .cornerRadius(20)
                    .shadow(radius: 10)
                    
                    // Evaluate Button
                    Button(action: {
                        withAnimation {
                            viewModel.evaluateExpense(input: amountText,
                                                        for: selectedCategory,
                                                        in: selectedCurrency)
                            showAssessment = true
                        }
                    }) {
                        Text("Evaluate Expense")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(
                                LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]),
                                               startPoint: .leading,
                                               endPoint: .trailing)
                            )
                            .cornerRadius(15)
                            .padding(.horizontal, 30)
                    }
                    
                    Spacer()
                    
                    NavigationLink(destination: AssessmentView(result: viewModel.assessment),
                                   isActive: $showAssessment) {
                        EmptyView()
                    }
                }
                .padding()
            }
            .navigationBarHidden(true)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Refresh Rate") {
                        Task { await viewModel.updateConversionRates() }
                    }
                }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

// MARK: - Assessment View

struct AssessmentView: View {
    var result: ExpenseAssessment?
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.indigo, Color.black]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            .drawingGroup()
            
            VStack(spacing: 20) {
                Text("Expense Analysis")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.top, 40)
                
                if let result = result {
                    assessmentResultView(for: result)
                } else {
                    Text("No assessment available.")
                        .foregroundColor(.white)
                }
                
                Spacer()
            }
            .padding()
        }
        .navigationBarTitle("", displayMode: .inline)
    }
    
    @ViewBuilder
    private func assessmentResultView(for result: ExpenseAssessment) -> some View {
        switch result {
        case .acceptable(let message):
            assessmentDetailView(image: "checkmark.seal.fill",
                                 title: "Good Expense",
                                 color: .green,
                                 message: message)
        case .overpriced(let message):
            assessmentDetailView(image: "xmark.octagon.fill",
                                 title: "Too Costly",
                                 color: .red,
                                 message: message)
        case .investForFuture(let message):
            assessmentDetailView(image: "lightbulb.fill",
                                 title: "Consider Investing",
                                 color: .yellow,
                                 message: message,
                                 spacing: 20)
        }
    }
    
    private func assessmentDetailView(image: String,
                                      title: String,
                                      color: Color,
                                      message: String,
                                      spacing: CGFloat = 20) -> some View {
        VStack(spacing: spacing) {
            Image(systemName: image)
                .resizable()
                .scaledToFit()
                .frame(width: 100, height: 100)
                .foregroundColor(color)
                .padding(.bottom, 10)
            
            Text(title)
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(color)
                .padding(.bottom, 5)
            
            Text(message)
                .multilineTextAlignment(.center)
                .font(.body)
                .foregroundColor(.white)
                .padding(.horizontal, 30)
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.white.opacity(0.1))
                .shadow(color: Color.black.opacity(0.2), radius: 10, x: 0, y: 5)
        )
        .padding(.horizontal, 20)
    }
}
